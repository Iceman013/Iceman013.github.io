function Blind(tag, name, effect) {
    this.tag = tag;
    this.name = name;
    this.effect = effect;
}